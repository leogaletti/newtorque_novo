<link rel="stylesheet" href="style.css" type="text/css">
<table width="100%" height="150" border="0" align="center" cellpadding="0" cellspacing="0" class="style3">
	<tr bgcolor="#000033">
	<td width="500" rowspan="2" align="center" bgcolor="#000033"><img src="logo.png" width="300" height="100"></td>
	<td height="50" align="center"><strong>Gerenciador de conte&uacute;do do site</strong></td>
	</tr>
	<tr>
	<td align="right" bgcolor="#000033"><a href="sessao_sair.php"><img src="tit_adm_sair.gif" width="40" height="50" border="0"></a></td>
	</tr>
</table>
<table width="100%" align="center" cellpadding="0" cellspacing="0">
	<tr>
	<td colspan="8" bgcolor="#CA1D20">&nbsp; </td>
	</tr>
	<tr>
	<td align="center" bgcolor="#FFFFFF">&nbsp;
	</td>
	<td width="124" align="center" bgcolor="#FFFFFF"><a href="gerenciador_destaques.php"><img src="tit_destaques.gif" alt="" width="120" height="60" hspace="2" vspace="2" border="0" /></a><a href="gerenciador_noticias.php"></a></td>
	<td width="124" align="center" bgcolor="#FFFFFF"><a href="gerenciador_noticias.php"><img src="tit_noticias.gif" alt="" width="120" height="60" hspace="2" vspace="2" border="0" /></a><a href="gerenciador_destaques.php"></a></td>
	<td width="124" align="center" bgcolor="#FFFFFF"><a href="gerenciador_servicos.php"><img src="tit_servicos.gif" width="120" height="60" hspace="2" vspace="2" border="0"></a></td>
	<td width="124" align="center" bgcolor="#FFFFFF"><a href="gerenciador_servicos_executados.php"><img src="tit_servicos_executados.gif" alt="" width="120" height="60" hspace="2" vspace="2" border="0" /></a></td>
	<td width="124" align="center" bgcolor="#FFFFFF"><a href="gerenciador_linhas.php"><img src="tit_linhas.gif" width="120" height="60" hspace="2" vspace="2" border="0" /></a></td>
	<td width="124" align="center" bgcolor="#FFFFFF"><a href="gerenciador_clientes.php"><img src="tit_clientes.gif" width="120" height="60" hspace="2" vspace="2" border="0" /></a></td>
      <td align="center" bgcolor="#FFFFFF">&nbsp;</td>
	</tr>
	<tr>
	<td colspan="8" align="center" bgcolor="#CA1D20">&nbsp;
	</td>
	</tr>
	<tr>
      <td align="center" bgcolor="#FFFFFF">&nbsp; </td>
      <td align="center" bgcolor="#FFFFFF"><a href="edicao_pag_aempresa.php"><img src="tit_ed_pag_aempresa.gif" width="120" height="60" hspace="2" vspace="2" border="0" /></a></td>
      <td align="center" bgcolor="#FFFFFF"><a href="edicao_fotos_paginicial.php"><img src="tit_imagens_inicial.gif" width="120" height="60" hspace="2" vspace="2" border="0" /></a></td>
      <td align="center" bgcolor="#FFFFFF"><a href="edicao_textos_paginas.php"><img src="tit_textos_paginternas.gif" width="120" height="60" hspace="2" vspace="2" border="0" /></a></td>
      <td align="center" bgcolor="#FFFFFF"><a href="gerenciador_videos.php"><img src="tit_videos.gif" width="120" height="60" /></a></td>
      <td align="center" bgcolor="#FFFFFF"><a href="/stats" target="_blank"><img src="tit_estatisticas.gif" width="120" height="60" hspace="2" vspace="2" border="0" /></a></td>
      <td align="center" bgcolor="#FFFFFF"><a href="muda_senha.php"><img src="tit_mudasenha.gif" width="120" height="60" hspace="2" vspace="2" border="0" /></a></td>
      <td align="center" bgcolor="#FFFFFF">&nbsp;</td>
  </tr>
<tr>
  <td colspan="8" bgcolor="#CA1D20">&nbsp; </td>
</tr>
</table>
