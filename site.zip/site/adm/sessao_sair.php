<?
session_start();
session_destroy();
?>
<script language="JavaScript"> 
window.close(-1)
</script> 
